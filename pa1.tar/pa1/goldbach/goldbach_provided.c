#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

//Function declerations
bool is_prime(int n);

int main(int argc, char* argv[]) {
  int number = atoi(argv[1]);
}

bool is_prime(int n){
}
